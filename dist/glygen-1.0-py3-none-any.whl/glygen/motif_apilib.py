import os
import string
import random
import hashlib
import json
import datetime,time
import pytz
from collections import OrderedDict
from bson import json_util, ObjectId


from glygen.db import get_mongodb
from glygen.util import get_errors_in_query, sort_objects, order_obj, get_paginated_sections




def motif_detail(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj


    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    ts_list = []
    ts_list.append("0-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
     

    #Collect errors 
    error_list = get_errors_in_query("motif_detail", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}
    collection = "c_motif"


    default_hash = {"offset":1, "limit":20, "sort":"glytoucan_ac", "order":"asc"}
    for key in default_hash:
        if key not in query_obj:
            query_obj[key] = default_hash[key]
    
    mongo_query = {}
    if "motif_ac" in query_obj:
        mongo_query = {"motif_ac":{'$eq': query_obj["motif_ac"]}}
    elif "glytoucan_ac" in query_obj:
        mongo_query = {"glytoucan_ac":{'$eq': query_obj["glytoucan_ac"]}}
   
    if mongo_query == {}:
        return {"error_list":[{"error_code":"bad-query"}]}

    ts_list.append("1-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    motif_doc = dbh[collection].find_one(mongo_query)
    
    ts_list.append("2-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    #check for post-access error, error_list should be empty upto this line
    post_error_list = []
    if motif_doc == None:
        post_error_list.append({"error_code":"non-existent-record"})
        return {"error_list":post_error_list}

    
    url = config_obj["urltemplate"]["motif"] % (motif_doc["motif_ac"])
    glytoucan_url = config_obj["urltemplate"]["glytoucan"] % (motif_doc["glytoucan_ac"])
    motif_doc["motif"] = {
        "accession":motif_doc["motif_ac"], 
        "url":url,
        "glytoucan_ac":motif_doc["glytoucan_ac"],
        "glytoucan_url":glytoucan_url
    }

    prop_list = ["motif", "glytoucan","name",  "mass", "publication"]
    prop_list += ["synonym", "crossref","keywords", "reducing_end","aglycon","reducing_end",
        "alignment_method", "dictionary", 
        "iupac","wurcs","glycoct","inchi","smiles_isomeric", "glycam", "byonic", "gwb",
        "biomarkers", "section_stats"
    ]


    res_obj = {}
    for k in motif_doc:
        if k in prop_list:
            res_obj[k] = motif_doc[k]

    ts_list.append("3-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    q = {"record_id":{'$eq': motif_doc["glytoucan_ac"].upper()}}
    history_obj = dbh["c_idtrack"].find_one(q)
    res_obj["history"] = history_obj["history"] if history_obj != None else []

    
    ts_list.append("4a-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))



    prj_obj = {"glytoucan_ac":1, "motifs":1, "glycoprotein":1, "enzyme":1, 
        "mass":1, "number_monosaccharides":1, "iupac":1, "glycoct":1}

    mongo_query = {"motifs.id": {'$eq': motif_doc["motif_ac"]}}
    doc_list = list(dbh["c_glycan"].find(mongo_query, prj_obj))

    ts_list.append("4b-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    results = get_parent_glycans(motif_doc["motif_ac"], doc_list, res_obj)

    ts_list.append("5-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    sorted_id_list = sort_objects(results, config_obj["glycan_list"]["returnfields"], 
                                        query_obj["sort"], query_obj["order"])
    
    #check for post-access error, error_list should be empty upto this line
    if int(query_obj["offset"]) < 1 or int(query_obj["offset"]) > len(results):
        post_error_list.append({"error_code":"invalid-parameter-value", "field":"offset"})
        return {"error_list":post_error_list, "n":len(results)}

    start_index = int(query_obj["offset"]) - 1
    stop_index = start_index + int(query_obj["limit"])
    res_obj["results"] = []

    for i in sorted_id_list[start_index:stop_index]:
        res_obj["results"].append(results[i])

    res_obj["pagination"] = {"offset":query_obj["offset"], "limit":query_obj["limit"],
        "total_length":len(results), "sort":query_obj["sort"], "order":query_obj["order"]}
    res_obj["query"] = query_obj

 
    if "paginated_tables" in query_obj:
        table_id_list = []
        for o in query_obj["paginated_tables"]:
            if o["table_id"] not in table_id_list:
                table_id_list.append(o["table_id"])
        sec_tables = get_paginated_sections(res_obj, query_obj, table_id_list)
        if "error_list" in sec_tables:
            return sec_tables
        for sec in sec_tables:
            res_obj[sec] = sec_tables[sec]

    ts_list.append("7-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
    #return ts_list

    return order_obj(res_obj, config_obj["objectorder"]["glycan"])



def get_parent_glycans(motif_ac, doc_list, res_obj):

    results = []
    for doc in doc_list:
        if "motifs" in doc:
            for o in doc["motifs"]:
                if "name" not in res_obj and o["id"] == motif_ac:
                    res_obj["name"] = o["name"]

        glytoucan_ac = doc["glytoucan_ac"]
        seen = {"uniprot_canonical_ac":{}, "enzyme":{}}
        if "glycoprotein" in doc:
            for o in doc["glycoprotein"]:
                seen["uniprot_canonical_ac"][o["uniprot_canonical_ac"].lower()] = True

        if "enzyme" in doc:
            for o in doc["enzyme"]:
                seen["enzyme"][o["gene"].lower()] = True

        mass = doc["mass"] if "mass" in doc else -1
        number_monosaccharides = doc["number_monosaccharides"] if "number_monosaccharides" in doc else -1
        iupac = doc["iupac"] if "iupac" in doc else ""
        glycoct = doc["glycoct"] if "glycoct" in doc else ""
        results.append({
            "glytoucan_ac":glytoucan_ac
            ,"mass": mass 
            ,"number_monosaccharides": number_monosaccharides
            ,"number_proteins": len(seen["uniprot_canonical_ac"].keys())
            ,"number_enzymes": len(seen["enzyme"].keys()) 
            ,"iupac": iupac
            ,"glycoct": glycoct
        })


    return results







