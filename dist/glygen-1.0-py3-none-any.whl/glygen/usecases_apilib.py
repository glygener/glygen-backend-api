import os
import string
import random
import hashlib
import json
import datetime,time
import pytz
from pytz import timezone
from bson import json_util, ObjectId

from glygen.db import get_mongodb
from glygen.util import get_errors_in_query, order_obj, extract_name, cache_hitlist, get_hash_id

from glygen.protein_apilib import get_protein_list_object

from glygen.util import get_taxid2name



def search_init(config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("usecases_search_init",{}, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    collection = "c_searchinit"

    res_obj =  dbh[collection].find_one({})
    if res_obj == None or "usecases" not in res_obj:
        return {"error_list":[{"error_code":"non-existent-search-init"}]}

    return res_obj["usecases"]



def glycan_to_biosynthesis_enzymes(query_obj, config_obj):
    
    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("usecases_group_one", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}


    record_type = "protein"
    api_name = "glycan_to_biosynthesis_enzymes"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}


    mongo_query = get_mongo_query("glycan_to_biosynthesis_enzymes",  query_obj)
    #return mongo_query


    collection = "c_glycan"    
    cache_collection = "c_usercache"

    search_type = "glycan_to_biosynthesis_enzymes"
    record_list = []
    prj_obj = {"enzyme":1}
    obj = dbh[collection].find_one(mongo_query, prj_obj)
    seen = {}
    if obj != None:
        for o in obj["enzyme"]:
            if o["uniprot_canonical_ac"] not in seen:
                seen[o["uniprot_canonical_ac"]] = True
                tax_id = o["tax_id"]
                if query_obj["tax_id"] == 0:
                    record_list.append(o["uniprot_canonical_ac"])
                elif tax_id == query_obj["tax_id"]:
                    record_list.append(o["uniprot_canonical_ac"])

    taxid2name = get_taxid2name(default=True)
    if str(query_obj["tax_id"]) not in taxid2name:
        return {"list_id":""}
    query_obj["organism"] = {"id":query_obj["tax_id"], "name":taxid2name[str(query_obj["tax_id"])]}
    query_obj.pop("tax_id")


    res_obj = {}
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":search_type
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}
    
    

    return res_obj


def glycan_to_glycoproteins(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("usecases_group_one", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "protein"
    api_name = "glycan_to_glycoproteins"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}

    mongo_query = get_mongo_query("glycan_to_glycoproteins",  query_obj)
    #return mongo_query

    collection = "c_glycan"    
    cache_collection = "c_usercache"


    search_type = "glycan_to_glycoproteins"
    record_list = []
    seen = {}
    prj_obj = {"glycoprotein":1}
    for obj in dbh[collection].find(mongo_query, prj_obj):
        for o in obj["glycoprotein"]:
            if o["uniprot_canonical_ac"] not in seen:
                seen[o["uniprot_canonical_ac"]] = True
                tax_id = o["tax_id"]
                if query_obj["tax_id"] == 0:
                    record_list.append(o["uniprot_canonical_ac"])
                elif tax_id == query_obj["tax_id"]:
                    record_list.append(o["uniprot_canonical_ac"])

    taxid2name = get_taxid2name(default=True)
    if str(query_obj["tax_id"]) not in taxid2name:
        return {"list_id":""}
    query_obj["organism"] = {"id":query_obj["tax_id"], "name":taxid2name[str(query_obj["tax_id"])]}
    query_obj.pop("tax_id")

    res_obj = {}
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":search_type
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}



    return res_obj

def glycan_to_enzyme_gene_loci(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("usecases_group_one", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "gene_locus"
    api_name = "glycan_to_enzyme_gene_loci"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}

    mongo_query = get_mongo_query("glycan_to_enzyme_gene_loci", query_obj)
    #return mongo_query
        
    collection = "c_glycan"    
    cache_collection = "c_usercache"

    results = []
    prj_obj = {"enzyme":1}
    for obj in dbh[collection].find(mongo_query, prj_obj):
        for o in obj["enzyme"]:
            plist_obj,tax_id = get_genelocus_list_fields(dbh, o["uniprot_canonical_ac"])
            if plist_obj == {}:
                continue
            if query_obj["tax_id"] == 0:
                results.append(plist_obj)
            elif tax_id == query_obj["tax_id"]:
                results.append(plist_obj)
    taxid2name = get_taxid2name(default=True)
    if str(query_obj["tax_id"]) not in taxid2name:
        return {"list_id":""}
    
    query_obj["organism"] = {"id":query_obj["tax_id"], "name":taxid2name[str(query_obj["tax_id"])]}
    query_obj.pop("tax_id")


    res_obj = {}
    if len(results) == 0:
        res_obj = {"list_id":""}
    else:
        ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime('%Y-%m-%d %H:%M:%S %Z%z')
        search_results_obj = {}
        search_results_obj["list_id"] = list_id
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":"gene_locus",
            "search_type":"glycan_to_enzyme_gene_loci"
        }
        search_results_obj["cache_info"] = cache_info
        search_results_obj["results"] = results
        result = dbh[cache_collection].delete_many({"list_id":list_id})
        result = dbh[cache_collection].insert_one(search_results_obj)
        res_obj["list_id"] = list_id

    return res_obj


def biosynthesis_enzyme_to_glycans(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("usecases_group_two", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "glycan"
    api_name = "biosynthesis_enzyme_to_glycans"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}

    mongo_query = get_mongo_query("biosynthesis_enzyme_to_glycans", query_obj)
    #return mongo_query


    collection = "c_glycan"
    cache_collection = "c_usercache"

    search_type = "biosynthesis_enzyme_to_glycans"
    record_list = []
    prj_obj = {"glytoucan_ac":1}
    for obj in dbh[collection].find(mongo_query, prj_obj):
        record_list.append(obj["glytoucan_ac"])

    taxid2name = get_taxid2name(default=True)
    if str(query_obj["tax_id"]) not in taxid2name:
        return {"list_id":""}
    query_obj["organism"] = {"id":query_obj["tax_id"], "name":taxid2name[str(query_obj["tax_id"])]}
    query_obj.pop("tax_id")


    res_obj = {}
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":search_type
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}

    return res_obj


def protein_to_glycosequons(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj
 
    #Collect errors 
    error_list = get_errors_in_query("usecases_group_seven", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "glycosequon"
    api_name = "protein_to_glycosequons"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}

    #mongo_query = {"uniprot_canonical_ac":query_obj["uniprot_canonical_ac"]}
    mongo_query = {
        "$or":[
            {"uniprot_canonical_ac":{'$eq': query_obj["uniprot_canonical_ac"]}},
            {"uniprot_ac":{'$eq': query_obj["uniprot_canonical_ac"]}}
        ]
    }
    #return mongo_query


    collection = "c_protein"    
    cache_collection = "c_usercache"

    obj = dbh[collection].find_one(mongo_query)
    tmp_list = obj["site_annotation"] if obj != None else []
    results = []
    for o in tmp_list:
        if o["annotation"] == "n_glycosylation_sequon":
            results.append(o)
    

    res_obj = {}
    if len(results) == 0:
        res_obj = {"list_id":""}
    else:
        ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime('%Y-%m-%d %H:%M:%S %Z%z')
        search_results_obj = {}
        search_results_obj["list_id"] = list_id
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":"glycosequon",
            "search_type":"protein_to_glycosequons"
        }
        search_results_obj["cache_info"] = cache_info
        search_results_obj["results"] = results
        result = dbh[cache_collection].delete_many({"list_id":list_id})
        result = dbh[cache_collection].insert_one(search_results_obj)
        res_obj["list_id"] = list_id

    return res_obj



def protein_to_orthologs(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj
 
    #Collect errors 
    error_list = get_errors_in_query("usecases_group_three", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "protein"
    api_name = "protein_to_orthologs"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}

    #mongo_query = {"uniprot_canonical_ac":query_obj["uniprot_canonical_ac"]}
    mongo_query = {
        "$or":[
            {"uniprot_canonical_ac":{'$eq': query_obj["uniprot_canonical_ac"]}},
            {"uniprot_ac":{'$eq': query_obj["uniprot_canonical_ac"]}}
        ]   
    }
    #return mongo_query


    collection = "c_protein"    
    cache_collection = "c_usercache"

    results = []
    obj = dbh[collection].find_one(mongo_query)
    
    results = obj["orthologs"] if obj != None else []

    res_obj = {}
    if len(results) == 0:
        res_obj = {"list_id":""}
    else:
        ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime('%Y-%m-%d %H:%M:%S %Z%z')
        search_results_obj = {}
        search_results_obj["list_id"] = list_id
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":"ortholog",
            "search_type":"protein_to_orthologs"
        }
        search_results_obj["cache_info"] = cache_info
        search_results_obj["results"] = results
        result = dbh[cache_collection].delete_many({"list_id":list_id})
        result = dbh[cache_collection].insert_one(search_results_obj)
        res_obj["list_id"] = list_id

    return res_obj



def species_to_glycosyltransferases(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj


    #Collect errors 
    error_list = get_errors_in_query("usecases_group_four", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "protein"
    api_name = "species_to_glycosyltransferases"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}


    mongo_query = get_mongo_query("species_to_glycosyltransferases",  query_obj)
    #return mongo_query

    collection = "c_protein"    
    cache_collection = "c_usercache"

    search_type = "species_to_glycosyltransferases"
    record_list = []
    for obj in dbh[collection].find(mongo_query, config_obj["projectedfields"][collection]):
        record_list.append(obj["uniprot_canonical_ac"])

    taxid2name = get_taxid2name(default=True)
    if str(query_obj["tax_id"]) not in taxid2name:
        return {"list_id":""}
    query_obj["organism"] = {"id":query_obj["tax_id"], "name":taxid2name[str(query_obj["tax_id"])]}
    query_obj.pop("tax_id")

    res_obj = {}
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":search_type
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}

    return res_obj


def species_to_glycohydrolases(query_obj, config_obj):
    
    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("usecases_group_four", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "protein"
    api_name = "species_to_glycohydrolases"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}

    mongo_query = get_mongo_query("species_to_glycohydrolases",  query_obj)
    #return mongo_query

    collection = "c_protein"    
    cache_collection = "c_usercache"

    search_type = "species_to_glycohydrolases"
    record_list = []
    for obj in dbh[collection].find(mongo_query, config_obj["projectedfields"][collection]):
        record_list.append(obj["uniprot_canonical_ac"])

    taxid2name = get_taxid2name(default=True)
    if str(query_obj["tax_id"]) not in taxid2name:
        return {"list_id":""}
    query_obj["organism"] = {"id":query_obj["tax_id"], "name":taxid2name[str(query_obj["tax_id"])]}
    query_obj.pop("tax_id")

    res_obj = {}
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":search_type
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}

    return res_obj



def species_to_glycoproteins(query_obj, config_obj):
    
    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("usecases_group_five", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "protein"
    
    # changing the api_name so that it maches with cachenames in c_initcache
    #api_name = "species_to_glycoproteins"
    api_name = "protein_search"
        
    list_id = get_hash_id(api_name, record_type, query_obj)
    #return {"list_id":list_id, "query_obj":query_obj}

    cache_coll = "c_initcache"
    mongo_query = {"list_id":list_id}
    cached_obj = dbh[cache_coll].find_one(mongo_query)
    if cached_obj == None:
        cache_coll = "c_usercache"
        cached_obj = dbh[cache_coll].find_one(mongo_query)

    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id, "result_count":cached_obj["total_count"]}





    mongo_query = get_mongo_query("species_to_glycoproteins",  query_obj)
    #return mongo_query

    collection = "c_protein"    
    cache_collection = "c_usercache"


    search_type = "species_to_glycoproteins"
    record_list = []
    for obj in dbh[collection].find(mongo_query, config_obj["projectedfields"][collection]):
        record_list.append(obj["uniprot_canonical_ac"])

    taxid2name = get_taxid2name(default=True)
    if str(query_obj["tax_id"]) not in taxid2name:
        return {"list_id":""}
    query_obj["organism"] = {"id":query_obj["tax_id"], "name":taxid2name[str(query_obj["tax_id"])]}
    query_obj.pop("tax_id")

    res_obj = {}
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":search_type
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}

    return res_obj


def disease_to_glycosyltransferases(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj
 
    #Collect errors 
    error_list = get_errors_in_query("usecases_group_six", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}
   
    record_type = "protein"
    api_name = "disease_to_glycosyltransferases"
    list_id = get_hash_id(api_name, record_type, query_obj)
    cache_coll = "c_usercache"
    cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id}
 
    mongo_query = get_mongo_query("disease_to_glycosyltransferases",  query_obj)
    #return mongo_query

    collection = "c_protein"    
    cache_collection = "c_usercache"


    search_type = "disease_to_glycosyltransferases"
    record_list = []
    for obj in dbh[collection].find(mongo_query, config_obj["projectedfields"][collection]):
        record_list.append(obj["uniprot_canonical_ac"])

    taxid2name = get_taxid2name(default=True)
    if str(query_obj["tax_id"]) not in taxid2name:
        return {"list_id":""}
    query_obj["organism"] = {"id":query_obj["tax_id"], "name":taxid2name[str(query_obj["tax_id"])]}
    query_obj.pop("tax_id")

    res_obj = {}
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    cache_coll = "c_usercache"
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":search_type
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}

    return res_obj



def genelocus_list(listcache_id, query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    cache_collection = "c_usercache"
    if cache_collection not in dbh.collection_names():
        return {"error_list":[{"error_code":"open-connection-failed"}]}

    res_obj = {}
    #check if submitted fields are allowed and contain valid values
    field_list = ["id", "offset", "limit", "sort", "order"]
    max_query_value_len = config_obj["max_query_value_len"]
    for field in query_obj:
        if field not in field_list:
            return {"error_list":[{"error_code":"unexpected-field-in-query"}]}
        if len(str(query_obj[field])) > max_query_value_len:
            return {"error_list":[{"error_code":"invalid-parameter-value-length"}]}

    #Check for required parameters
    key_list = ["id"]
    for key in key_list:
        if key not in query_obj:
            return {"error_list":[{"error_code":"missing-parameter"}]}
        if str(query_obj[key]).strip() == "":
            return {"error_list":[{"error_code":"invalid-parameter-value"}]}
            
    cached_obj = dbh[cache_collection].find_one({"list_id":query_obj["id"]})
    if cached_obj == None:
        return {"error_list":[{"error_code":"non-existent-search-results"}]}


    


    default_hash = {"offset":1, "limit":20, "sort":"gene_name", "order":"asc"}
    for key in default_hash:
        if key not in query_obj:
            query_obj[key] = default_hash[key]
        else:
            #check type for submitted int fields
            if key in ["offset", "limit"]:
                if type(query_obj[key]) is not int:
                    return {"error_list":[{"error_code":"invalid-parameter-value"}]}
            #check type for submitted selection fields
            if key in ["order"]:
                if query_obj[key] not in ["asc", "desc"]:
                    return {"error_list":[{"error_code":"invalid-parameter-value"}]}

    sorted_id_list = sort_objects(cached_obj["results"], query_obj["sort"], query_obj["order"])
    

    
    cached_obj["cache_info"]["cache_id"] = query_obj["id"]
    cached_obj["cache_info"]["listcache_id"] = listcache_id


    res_obj = {"cache_info":cached_obj["cache_info"]}

    if len(cached_obj["results"]) == 0:
        return {}
    if int(query_obj["offset"]) < 1 or int(query_obj["offset"]) > len(cached_obj["results"]):
            return {"error_list":[{"error_code":"invalid-parameter-value"}]}
    start_index = int(query_obj["offset"]) - 1
    stop_index = start_index + int(query_obj["limit"])
    res_obj["results"] = []

    for obj_id in sorted_id_list[start_index:stop_index]:
        obj = cached_obj["results"][obj_id]
        obj["filter_code"] = "0"
        res_obj["results"].append(order_obj(obj, config_obj["objectorder"]["protein"]))

    res_obj["pagination"] = {"offset":query_obj["offset"], "limit":query_obj["limit"],
        "total_length":len(cached_obj["results"]), "sort":query_obj["sort"], "order":query_obj["order"]}
    return res_obj



def glycosequon_list(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj
    cache_collection = "c_usercache"
    if cache_collection not in dbh.collection_names():
        return {"error_list":[{"error_code":"open-connection-failed"}]}
    res_obj = {}
    #check if submitted fields are allowed and contain valid values
    field_list = ["id", "offset", "limit", "sort", "order"]
    max_query_value_len = config_obj["max_query_value_len"]
    for field in query_obj:
        if field not in field_list:
            return {"error_list":[{"error_code":"unexpected-field-in-query"}]}
        if len(str(query_obj[field])) > max_query_value_len:
            return {"error_list":[{"error_code":"invalid-parameter-value-length"}]}

    #Check for required parameters
    key_list = ["id"]
    for key in key_list:
        if key not in query_obj:
            return {"error_list":[{"error_code":"missing-parameter"}]}
        if str(query_obj[key]).strip() == "":
            return {"error_list":[{"error_code":"invalid-parameter-value"}]}


    cached_obj = dbh[cache_collection].find_one({"list_id":query_obj["id"]})
    if cached_obj == None:
        return {"error_list":[{"error_code":"non-existent-search-results"}]}

    default_hash = {"offset":1, "limit":20, "sort":"id", "order":"asc"}
    for key in default_hash:
        if key not in query_obj:
            query_obj[key] = default_hash[key]
        else:
            #check type for submitted int fields
            if key in ["offset", "limit"]:
                if type(query_obj[key]) is not int:
                    return {"error_list":[{"error_code":"invalid-parameter-value"}]}
            #check type for submitted selection fields
            if key in ["order"]:
                if query_obj[key] not in ["asc", "desc"]:
                    return {"error_list":[{"error_code":"invalid-parameter-value"}]}

    sorted_id_list = sort_objects(cached_obj["results"], query_obj["sort"], query_obj["order"])
    res_obj = {"cache_info":cached_obj["cache_info"]}

    if len(cached_obj["results"]) == 0:
        return {}
    if int(query_obj["offset"]) < 1 or int(query_obj["offset"]) > len(cached_obj["results"]):
        return {"error_list":[{"error_code":"invalid-parameter-value"}]}

    start_index = int(query_obj["offset"]) - 1
    stop_index = start_index + int(query_obj["limit"])
    res_obj["results"] = []

    for obj_id in sorted_id_list[start_index:stop_index]:
        obj = cached_obj["results"][obj_id]
        res_obj["results"].append(order_obj(obj, config_obj["objectorder"]["protein"]))

    res_obj["pagination"] = {"offset":query_obj["offset"], "limit":query_obj["limit"],
        "total_length":len(cached_obj["results"]), "sort":query_obj["sort"], "order":query_obj["order"]}
    return res_obj




def ortholog_list(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj
    cache_collection = "c_usercache"
    if cache_collection not in dbh.collection_names():
        return {"error_list":[{"error_code":"open-connection-failed"}]}

    res_obj = {}
    #check if submitted fields are allowed and contain valid values
    field_list = ["id", "offset", "limit", "sort", "order"]
    max_query_value_len = config_obj["max_query_value_len"]
    for field in query_obj:
        if field not in field_list:
            return {"error_list":[{"error_code":"unexpected-field-in-query"}]}
        if len(str(query_obj[field])) > max_query_value_len:
            return {"error_list":[{"error_code":"invalid-parameter-value-length"}]}

    #Check for required parameters
    key_list = ["id"]
    for key in key_list:
        if key not in query_obj:
            return {"error_list":[{"error_code":"missing-parameter"}]}
        if str(query_obj[key]).strip() == "":
            return {"error_list":[{"error_code":"invalid-parameter-value"}]}

    cached_obj = dbh[cache_collection].find_one({"list_id":query_obj["id"]})
    if cached_obj == None:
        return {"error_list":[{"error_code":"non-existent-search-results"}]}
    default_hash = {"offset":1, "limit":20, "sort":"id", "order":"asc"}
    for key in default_hash:
        if key not in query_obj:
            query_obj[key] = default_hash[key]
        else:
            #check type for submitted int fields
            if key in ["offset", "limit"]:
                if type(query_obj[key]) is not int:
                    return {"error_list":[{"error_code":"invalid-parameter-value"}]}
            #check type for submitted selection fields
            if key in ["order"]:
                if query_obj[key] not in ["asc", "desc"]:
                    return {"error_list":[{"error_code":"invalid-parameter-value"}]}
    sorted_id_list = sort_objects(cached_obj["results"], query_obj["sort"], query_obj["order"])
    res_obj = {"cache_info":cached_obj["cache_info"]}

    if len(cached_obj["results"]) == 0:
        return {}
    if int(query_obj["offset"]) < 1 or int(query_obj["offset"]) > len(cached_obj["results"]):
	    return {"error_list":[{"error_code":"invalid-parameter-value"}]}
    start_index = int(query_obj["offset"]) - 1
    stop_index = start_index + int(query_obj["limit"])
    res_obj["results"] = []

    for obj_id in sorted_id_list[start_index:stop_index]:
        obj = cached_obj["results"][obj_id]
        res_obj["results"].append(order_obj(obj, config_obj["objectorder"]["protein"]))

    res_obj["pagination"] = {"offset":query_obj["offset"], "limit":query_obj["limit"],
        "total_length":len(cached_obj["results"]), "sort":query_obj["sort"], "order":query_obj["order"]}
    return res_obj


def get_protein_list_fields(dbh, uniprot_canonical_ac):

    collection = "c_protein"
    obj = dbh[collection].find_one({"uniprot_canonical_ac":uniprot_canonical_ac})
    plist_obj = get_protein_list_object(obj)
    return plist_obj, obj["species"][0]["taxid"]

def get_glycan_list_fields(dbh, glytoucan_ac):
  
    collection = "c_glycan"
    obj = dbh[collection].find_one({"glytoucan_ac":glytoucan_ac})

    seen = {"enzyme":{}, "glycoprotein":{}}
    for o in obj["glycoprotein"]:
        seen["glycoprotein"][o["uniprot_canonical_ac"].lower()] = True
    for o in obj["enzyme"]:
        seen["enzyme"][o["uniprot_canonical_ac"].lower()] = True

    mass = obj["mass"] if "mass" in obj else -1
    mass_pme = obj["mass_pme"] if "mass_pme" in obj else -1

    return {
        "glytoucan_ac":glytoucan_ac
        ,"mass":mass
        ,"mass_pme":mass_pme
        ,"number_monosaccharides": obj["number_monosaccharides"]
        ,"number_enzymes":len(seen["enzyme"].keys()) 
        ,"number_proteins":len(seen["glycoprotein"].keys()) 
        ,"iupac": obj["iupac"] if "iupac" in obj else ""
        ,"glycoct": obj["glycoct"]
    }


def get_genelocus_list_fields(dbh, uniprot_canonical_ac):

    collection = "c_protein"
    obj = dbh[collection].find_one({"uniprot_canonical_ac":uniprot_canonical_ac})
    if obj == None:
        return {}, -1

    protein_name = extract_name(obj["protein_names"], "recommended", "UniProtKB")
    gene_name = obj["gene"][0]["name"] if obj["gene"] != [] else ""
    organism = obj["species"][0]["common_name"] if obj["species"] != [] else ""
    tax_id = obj["species"][0]["taxid"] if obj["species"] != [] else 0
    gene_url = obj["gene"][0]["url"]
    for o in obj["isoforms"]:
        if o["isoform_ac"] == uniprot_canonical_ac:
            if o["locus"] == {}:
                return {}, tax_id
            plist_obj = {
                "uniprot_canonical_ac":uniprot_canonical_ac
                ,"protein_name":protein_name
                ,"gene_name":gene_name
                ,"gene_link":gene_url
                ,"tax_id":tax_id
                ,"organism":organism
                ,"chromosome":o["locus"]["chromosome"]
                ,"start_pos":o["locus"]["start_pos"]
                ,"end_pos":o["locus"]["end_pos"]
            }
            return plist_obj, tax_id





def get_mongo_query(svc_name, query_obj):

    svc_grp = [
            []
            ,["glycan_to_biosynthesis_enzymes","glycan_to_glycoproteins", "glycan_to_enzyme_gene_loci"]
            ,["biosynthesis_enzyme_to_glycans"]
            ,["species_to_glycosyltransferases"]
            ,["species_to_glycohydrolases"]
            ,["species_to_glycoproteins"]
            ,["disease_to_glycosyltransferases"]
    ] 


    cond_objs = []
    if svc_name in svc_grp[1]:
        #For this services, only search by glytoucan_ac, tax_id filtering is done to the proteins
        if "glytoucan_ac" in query_obj:
            cond_objs.append({"glytoucan_ac":{'$eq': query_obj["glytoucan_ac"]}})
    elif svc_name in svc_grp[2]:
        if "uniprot_canonical_ac" in query_obj:
            #cond_objs.append({"enzyme.uniprot_canonical_ac": {'$eq': query_obj["uniprot_canonical_ac"]}})
            cond_objs.append({"enzyme.uniprot_canonical_ac": {'$regex': query_obj["uniprot_canonical_ac"], '$options': 'i'}})

        if "tax_id" in query_obj:
            if query_obj["tax_id"] > 0:
                tax_id_q_obj = {
                    "$or":[
                        {"species.taxid": {'$eq': query_obj["tax_id"]}},
                        {"species.taxid": {'$eq': str(query_obj["tax_id"])}}
                    ]
                }
                cond_objs.append(tax_id_q_obj)
                #cond_objs.append({"species.taxid": {'$eq': query_obj["tax_id"]}})
    elif svc_name in svc_grp[3]:
        if "tax_id" in query_obj:
            if query_obj["tax_id"] > 0:
                tax_id_q_obj = {
                    "$or":[
                        {"species.taxid": {'$eq': query_obj["tax_id"]}},
                        {"species.taxid": {'$eq': str(query_obj["tax_id"])}}
                    ]   
                }
                cond_objs.append(tax_id_q_obj)
                #cond_objs.append({"species.taxid": {'$eq': query_obj["tax_id"]}})
            cond_objs.append({"keywords": "glycosyltransferase-activity"}) 
    elif svc_name in svc_grp[4]:
        if "tax_id" in query_obj:
            if query_obj["tax_id"] > 0:
                tax_id_q_obj = {
                    "$or":[
                        {"species.taxid": {'$eq': query_obj["tax_id"]}},
                        {"species.taxid": {'$eq': str(query_obj["tax_id"])}}
                    ]
                }
                cond_objs.append(tax_id_q_obj)
                #cond_objs.append({"species.taxid": {'$eq': query_obj["tax_id"]}})
            cond_objs.append({"keywords": "glycohydrolase-activity"})
    elif svc_name in svc_grp[5]:
        if "tax_id" in query_obj:
            if query_obj["tax_id"] > 0:
                tax_id_q_obj = {
                    "$or":[
                        {"species.taxid": {'$eq': query_obj["tax_id"]}},
                        {"species.taxid": {'$eq': str(query_obj["tax_id"])}}
                    ]
                }
                cond_objs.append(tax_id_q_obj)
                #cond_objs.append({"species.taxid": {'$eq': query_obj["tax_id"]}})
            
            if query_obj["glycosylation_evidence"] == "all_sites":
                cond_objs.append({"glycosylation": {'$gt': []}})
            elif query_obj["glycosylation_evidence"] == "sites_reported_with_glycans":
                oo = {"glycosylation.site_category_dict.reported_with_glycan":{"$eq":True}}
                cond_objs.append(oo)
            elif query_obj["glycosylation_evidence"] == "sites_reported_without_glycans":
                oo = {"glycosylation.site_category_dict.reported":{"$eq":True}}
                cond_objs.append(oo)
            elif query_obj["glycosylation_evidence"] == "all_reported_sites_with_without_glycans":
                or_list = [
                    {"glycosylation.site_category_dict.reported_with_glycan":{"$eq":True}},
                    {"glycosylation.site_category_dict.reported":{"$eq":True}}
                ]
                cond_objs.append({"$or":or_list})
            elif query_obj["glycosylation_evidence"] == "sites_detected_by_literature_mining":
                oo = {"glycosylation.site_category_dict.automatic_literature_mining":{"$eq":True}}
                cond_objs.append(oo)
            elif query_obj["glycosylation_evidence"] == "predicted_sites":
                or_list = [
                    {"glycosylation.site_category_dict.predicted":{"$eq":True}},
                    {"glycosylation.site_category_dict.predicted_with_glycan":{"$eq":True}}
                ]
                cond_objs.append({"$or":or_list})
            elif query_obj["glycosylation_evidence"] == "none":
                #to return empty list
                cond_objs.append({"glycosylation.evidence.database": {'$eq':"XYZzyz"}})
    elif svc_name in svc_grp[6]:
        if "tax_id" in query_obj:
            if query_obj["tax_id"] > 0:
                tax_id_q_obj = {
                    "$or":[
                        {"species.taxid": {'$eq': query_obj["tax_id"]}},
                        {"species.taxid": {'$eq': str(query_obj["tax_id"])}}
                    ]
                }
                cond_objs.append(tax_id_q_obj)
                #cond_objs.append({"species.taxid": {'$eq': query_obj["tax_id"]}})
            if query_obj["do_name"].strip() !=  "":
                q_one = {"disease.recommended_name.name": {'$regex': query_obj["do_name"], '$options': 'i'}}
                q_two = {"disease.synonyms.name": {'$regex': query_obj["do_name"], '$options': 'i'}}
                cond_objs.append({"$or":[q_one, q_two]})
            cond_objs.append({"keywords": "glycosyltransferase-activity"})
    mongo_query = {} if cond_objs == [] else { "$and": cond_objs }
    return mongo_query




def sort_objects(obj_list, field_name, order_type):

    seen = {
        "uniprot_canonical_ac":{} 
        ,"protein_name":{} 
        ,"gene_name":{}
        ,"chromosome":{}
        ,"start_pos":{}
        ,"end_pos":{}
        ,"organism":{}
        ,"tax_id":{}
    }

    grid_obj = {
        "uniprot_canonical_ac":[]
        ,"protein_name":[]
        ,"gene_name":[]
        ,"chromosome":[]
        ,"start_pos":[]
        ,"end_pos":[]
        ,"organism":[]
        ,"tax_id":[]
    }
    for i in range(0, len(obj_list)):
        obj = obj_list[i]
        if field_name in grid_obj and field_name in obj:
            grid_obj[field_name].append({"index":i, field_name:obj[field_name]})

    reverse_flag = True if order_type == "desc" else False
    key_list = []
    if field_name in grid_obj:
        sorted_obj_list = sorted(grid_obj[field_name], key=lambda x: x[field_name], reverse=reverse_flag)
        for o in sorted_obj_list:
            key_list.append(o["index"])
    return key_list








