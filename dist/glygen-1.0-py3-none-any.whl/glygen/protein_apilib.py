import os
import string
import random
import hashlib
import json
import datetime,time
import pytz
from collections import OrderedDict
from flask import (request, current_app)


from glygen.db import get_mongodb
from glygen.util import cache_hitlist, clean_obj, extract_name, get_errors_in_query, get_paginated_sections, transform_query_term, get_hash_id, filter_glyco_obj_list

from glygen.indexlib import use_indexed_search, search_one


def protein_search_init(config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("protein_searchinit",{}, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    collection = "c_searchinit"
    res_obj =  dbh[collection].find_one({})

    if "Undefined type" in res_obj["protein"]["glycosylation_types"]:
        res_obj["protein"]["glycosylation_types"].pop("Undefined type")

    collection = "c_aisearch"
    doc =  dbh[collection].find_one({})
    if doc != None:
        if "protein_ai_search" in doc:
            o = {"status":doc["protein_ai_search"], "token":os.environ["AISEARCH_TOKEN"]}
            res_obj["protein"]["ai_search"] = o



    return res_obj["protein"]



def search_simple(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj


    #Collect errors 
    error_list = get_errors_in_query("protein_search_simple", query_obj,config_obj)
    if error_list != []:
        return {"error_list":error_list}


    new_query_obj = json.loads(json.dumps(query_obj))
    if new_query_obj["term_category"] == "any":
        new_query_obj["term"] = transform_query_term(new_query_obj["term"])

    record_type = "protein"
    api_name = "protein_search_simple"
    list_id = get_hash_id(api_name, record_type, query_obj)
    
    cache_coll = "c_usercache"
    #cached_obj = dbh[cache_coll].find_one({"list_id":list_id})
    #if cached_obj != None:
    #    if len(cached_obj["results"]) > 0:
    #        return {"list_id":list_id}

    mongo_query = get_simple_mongo_query(new_query_obj)
    #return mongo_query

    collection = "c_protein"
    record_list = []
    prj_obj = {"uniprot_canonical_ac":1}
    for obj in dbh[collection].find(mongo_query,prj_obj):
        record_list.append(obj["uniprot_canonical_ac"])

    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {
            "query":query_obj,
            "ts":ts,
            "record_type":record_type,
            "search_type":"protein_search_simple"
        }
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id}
    res_obj["query"] = query_obj
    res_obj["resultcount"] = len(record_list)

    return res_obj




def protein_search(query_obj, config_obj):


    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts_list = []
    ts_list.append("0-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #field_info = config_obj["protein_search"]["field_info"]
    #return {"error_list":field_info}

    #Collect errors 
    error_list = get_errors_in_query("protein_search", query_obj,config_obj)
    if error_list != []:
        return {"error_list":error_list}

    record_type = "protein"
    api_name = "protein_search"
    list_id = get_hash_id(api_name, record_type, query_obj)
    
    #Get cached object
    cache_coll = "c_initcache"
    mongo_query = {"list_id":list_id}
    cached_obj = dbh[cache_coll].find_one(mongo_query)
    if cached_obj == None:
        cache_coll = "c_usercache"
        cached_obj = dbh[cache_coll].find_one(mongo_query)

    if cached_obj != None:
        if len(cached_obj["results"]) > 0:
            return {"list_id":list_id, "result_count":cached_obj["total_count"]}



    glygen_name_dict = {}
    for doc in dbh["c_species"].find({}):
        glygen_name_dict[doc["glygen_name"]] = True


    field2sec = {
        "gene_name":"gene",
        "protein_name":"protein_names",
        "go_term":"go_term",
        "disease_name":"disease",
        "biomarker.disease_name":"biomarkers",
        "biomarker.type":"biomarkers"
    }

    collection = "c_protein"
    ts_list.append("1a-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
    sf_dict = {}
    for f in query_obj:
        if f == "glycosylated_aa":
            sf_dict[f] = {}
            for ff in query_obj[f]:
                sf_dict[f][ff] = query_obj[f][ff]
        elif f not in ["operation", "query_type"]:
            if type(query_obj[f]) is dict:
                for ff in query_obj[f]:
                    new_f = f + "." + ff
                    sf_dict[new_f] = query_obj[f][ff]
            else:
                sf_dict[f] = query_obj[f]

    if "sequence.type" in sf_dict:
        sf_dict.pop("sequence.type")
    #return sf_dict

    #to address join search for biomarkers
    if "biomarker.disease_name" in sf_dict and "biomarker.type" in sf_dict:
        sf_dict["biomarker.disease_name"] += " " + sf_dict["biomarker.type"]
        sf_dict.pop("biomarker.type") 
               

    record_list = []
    if "tissue_id" in query_obj:
        record_list = get_expressed_proteins(dbh, query_obj)
        #return {"query":query_obj, "final":len(record_list)}
    else:
        hit_dict, hit_stat, seen_id = {}, {}, {}
        hit_dict, hit_stat, seen_id, tmp_ts_list,mquery = get_hit_dict(dbh, sf_dict,field2sec,api_name, glygen_name_dict,config_obj)
        #xxxx = get_hit_dict(dbh, sf_dict,field2sec,api_name, glygen_name_dict,config_obj)
        #return xxxx
        sf_list = list(sf_dict.keys())
        if sf_list != [] and hit_dict != {}:
            record_list = hit_dict[sf_list[0]] if sf_list[0] in hit_dict else []
            if len(sf_list) > 1:
                for i in range(1, len(sf_list)):
                    if sf_list[i] in hit_dict:
                        record_list = list(set(record_list).intersection(set(hit_dict[sf_list[i]])))
        #return {"hit_stat":hit_stat, "mquery":mquery, "final":len(record_list)}

    unmapped_obj_list = []
    if "uniprot_canonical_ac" in query_obj:
        unmapped_obj_list = get_unmapped_obj_list(query_obj["uniprot_canonical_ac"], seen_id)

    ts_list.append("3-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    ts = datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format)
    list_id = "" if len(record_list) == 0 else list_id
    if len(record_list) != 0:
        cache_info = {"query":query_obj,"ts":ts,"record_type":record_type,"search_type":"protein_search"}
        if unmapped_obj_list != []:
            cache_info["batch_info"] = {"unmapped":unmapped_obj_list}
        cache_hitlist(dbh,list_id,record_list,cache_info,cache_coll,config_obj)
    res_obj = {"list_id":list_id, "result_count":len(record_list)}

    ts_list.append("4-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
   
    #return ts_list
 
    return res_obj




def protein_alignment(query_obj, config_obj):


    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("protein_alignment", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}

    collection = "c_cluster"
    #mongo_query = {"uniprot_canonical_ac":query_obj["uniprot_canonical_ac"]}
    mongo_query = {"uniprot_canonical_ac":{'$regex':query_obj["uniprot_canonical_ac"], 
        '$options': 'i'}} 
    obj = dbh[collection].find_one(mongo_query)
    if obj == None:
        return {"error_list":[{"error_code":"non-existent-cluster for cluster type=%s, uniprot_canonical_ac=%s" % (query_obj["cluster_type"], query_obj["uniprot_canonical_ac"])}]}


    selected_cls_id = ""
    for cls_id in obj["clusterlist"]:
        if cls_id.find(query_obj["cluster_type"]) != -1:
            selected_cls_id = cls_id
            break


    if selected_cls_id == "":
        return {"error_list":[{"error_code":"non-existent-cluster-type"}]}

    #check for post-access error, error_list should be empty upto this line
    post_error_list = []
    if selected_cls_id == "":
        post_error_list.append({"error_code":"non-existent-record"})
        return {"error_list":post_error_list}


    collection = "c_alignment"
    mongo_query = {"cls_id":selected_cls_id}
    #return mongo_query
    obj = dbh[collection].find_one(mongo_query)


    if obj == None:
        post_error_list.append({"error_code":"non-existent-record"})
        return {"error_list":post_error_list}

    #If the object has a property that is not in the specs, remove it
    
    clean_obj(obj, config_obj["removelist"]["c_alignment"], "c_alignment")
   
    #make canoncal sequence first in the list
    new_list_one = []
    new_list_two = []
    canon_list = []
    for o in obj["sequences"]:
        canon_list.append(o["uniprot_ac"])
        if o["uniprot_ac"] == query_obj["uniprot_canonical_ac"]:
            new_list_one.append(o)
        else:
            new_list_two.append(o)
    obj["sequences"] = new_list_one + new_list_two
    new_obj = obj

    obj["details"] = []
    sec_list = [
        "uniprot_canonical_ac",
        "ptm_annotation", "glycation", "snv", "site_annotation", "glycosylation",
        "site_annotation", "glycosylation", "mutagenesis", "phosphorylation"
    ]
    collection = "c_protein"
    mongo_query = {"uniprot_canonical_ac":{"$in": canon_list}}
    for canon_obj in  dbh[collection].find(mongo_query):
        tmp_obj = {}
        for sec in sec_list:
            tmp_obj[sec] = canon_obj[sec]
        obj["details"].append(tmp_obj)

    return obj






def protein_detail(query_obj, config_obj):

    dbh, error_obj = get_mongodb()
    if error_obj != {}:
        return error_obj

    #Collect errors 
    error_list = get_errors_in_query("protein_detail", query_obj, config_obj)
    if error_list != []:
        return {"error_list":error_list}


    collection = "c_protein"

    mongo_query = {
        "$or":[
            {"uniprot_canonical_ac":{'$eq': query_obj["uniprot_canonical_ac"].upper()}},
            {"uniprot_ac":{'$eq': query_obj["uniprot_canonical_ac"].upper()}}
        ]
    }
    #mongo_query = {"uniprot_canonical_ac":{'$eq': query_obj["uniprot_canonical_ac"].upper()}}
    
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts_list = []
    ts_list.append("0-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    obj = dbh[collection].find_one(mongo_query)
    
    ts_list.append("1-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
 
    c_a = {"recordtype":{"$eq": "protein"}}
    c_b = {"record_id":{'$eq':query_obj["uniprot_canonical_ac"].upper()}}
    c_c = {"accessions":{'$regex':","+query_obj["uniprot_canonical_ac"].upper() + ",","$options":"i"}}
    if len(query_obj["uniprot_canonical_ac"]) == 6:
        c_b = {"record_id":{'$regex':query_obj["uniprot_canonical_ac"].upper(),"$options":"i"}}

    ts_list.append("2-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    q_one = {"$and":[c_a, c_b]}
    q_two = {"$and":[c_a, c_c]}
    history_obj_one = dbh["c_idtrack"].find_one(q_one)
    ts_list.append("3-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
    q_two = {"$and":[c_a, c_c]}
    ts_list.append("4-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))


    #check for post-access error, error_list should be empty upto this line
    post_error_list = []
    if obj == None:
        history_obj_two = dbh["c_idtrack"].find_one(q_two)
        post_error_list.append({"error_code":"non-existent-record"})
        res_obj = {"error_list":post_error_list}
        if history_obj_one != None:
            res_obj["reason"] = history_obj_one["history"][-1]
            if res_obj["reason"]["type"] == "discontinued":
                if res_obj["reason"]["description"].find("was in GlyGen") != -1:
                    res_obj["reason"]["type"] = "discontinued_in_glygen"
        elif history_obj_two != None:
            if history_obj_two["status"] == "primary":
                res_obj["reason"] = {
                    "description":"UniProtKB accession never been in GlyGen",
                    "type":"never_in_glygen_current_in_uniprotkb"
                }
            elif history_obj_two["status"] == "discontinued":
                res_obj["reason"] = {
                    "description":"Discontinued UniProtKB accession never been in GlyGen",
                    "type":"never_in_glygen_discontinued_in_uniprotkb"
                }
            elif history_obj_two["status"] == "secondary":
                q_ac = query_obj["uniprot_canonical_ac"].upper() + ":"
                t_list = history_obj_two["accessions"].split(q_ac)[1].split(",")[0].split(";")
                desc = "Old UniProtKB accession replaced by %s" % (", ".join(t_list))
                res_obj["reason"] = {
                    "description":desc, 
                    "replacement_id_list": t_list,
                    "type":"replacement_not_in_glygen"
                }
        else:
            res_obj["reason"] = {"type":"invalid","description": "Invalid accession"}
        return res_obj

    obj["_id"] = str(obj["_id"])

    # Get section objects if record is batched
    canon = query_obj["uniprot_canonical_ac"].upper()
    cond_list = []
    #cond_list.append({"batchid":{"$eq":1}})
    cond_list.append({"recordid": {"$regex":canon, "$options":"i"}})
    cond_list.append({"recordtype":{"$eq":"protein"}})
    q = {"$and":cond_list}
   
    #batch_doc = dbh["c_batch"].find_one(q)
    #if batch_doc != None:
    #    for sec in batch_doc["sections"]:
    #        if sec in obj:
    #            obj[sec] += batch_doc["sections"][sec]
 
    n_disease, n_non_disease = 0, 0
    for batch_doc in dbh["c_batch"].find(q):
        for sec in batch_doc["sections"]:
            if sec in obj:
                if sec == "snv":
                    for o in batch_doc["sections"][sec]:
                        if "disease" in o["keywords"] and n_disease < 20:
                            obj[sec].append(o)
                            n_disease += 1
                        if "disease" not in o["keywords"] and n_non_disease < 20:
                            obj[sec].append(o)
                            n_non_disease += 1
                else:
                    obj[sec] += batch_doc["sections"][sec]

 
    url = config_obj["urltemplate"]["uniprot"] % (obj["uniprot_canonical_ac"])
    obj["uniprot_id"] = obj["uniprot_id"] if "uniprot_id" in obj else ""
    obj["uniprot"] = {
        "uniprot_canonical_ac":obj["uniprot_canonical_ac"], 
        "uniprot_id":obj["uniprot_id"],
        "url":url,
        "length": obj["sequence"]["length"]
    }
    obj["history"] = history_obj_one["history"] if history_obj_one != None else []
    truncate_go_terms(obj)


    #return obj["section_stats"]    


    # Implementing filtering of glyco objects
    # this is expected to be done on pagination/page API, and is left here incase
    # someone sends "filtering" in payload
    if "filtering" in query_obj:
        query_filters, table_id = query_obj["filtering"]["filters"], query_obj["filtering"]["table_id"]
        r = filter_glyco_obj_list(table_id, obj["glycosylation"],query_filters,config_obj)
        table_obj_list, passed_obj_list, other_table_obj_list, filters_obj = r["a"], r["b"],r["c"],r["d"]
        obj["filters"] = filters_obj
        obj["glycosylation"] = passed_obj_list + other_table_obj_list
        #return {"all":len(table_obj_list), "passed":len(passed_obj_list)}


    if "paginated_tables" in query_obj:
        table_id_list = []
        for o in query_obj["paginated_tables"]:
            if o["table_id"] not in table_id_list:
                table_id_list.append(o["table_id"])
        sec_tables = get_paginated_sections(obj, query_obj, table_id_list, True)
        #return sec_tables
        if "error_list" in sec_tables:
            return sec_tables
        for sec in sec_tables:
            obj[sec] = sec_tables[sec]

    if "disease" in obj:
        for o in obj["disease"]:
            if "synonyms" in o:
                o.pop("synonyms")
    for k in ["snv", "expression_disease"]:
        if k in obj:
            for o in obj[k]:
                if "disease" in o:
                    for oo in o["disease"]:
                        if "synonyms" in oo:
                            oo.pop("synonyms")



    #xxxxx
    collection = "c_graph"
    mongo_query = {"record_id":{'$eq': canon}}
    doc = dbh[collection].find_one(mongo_query)
    graph_flag = "yes" if doc != None else "no"
    obj["tool_support"] = {"graph_view":graph_flag}
        
 
    clean_obj(obj, config_obj["removelist"]["c_protein"], "c_protein")
    ts_list.append("END-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
    #return {"tslist":ts_list}


    return obj



def truncate_go_terms(obj):
    
    if "categories" not in obj["go_annotation"]:
        return
    for o in obj["go_annotation"]["categories"]:
        tmp_list = []
        o["go_terms"] = sorted(o["go_terms"], key = lambda i: i['name'].lower())
        n = 0
        for t in o["go_terms"]:
            n += 1
            if n > 5:
                break
            tmp_list.append(t)
        o["go_terms"] = tmp_list
       
    return




def get_simple_mongo_query(query_obj):


    #query_term = "\"%s\"" % (query_obj["term"])
    query_term = query_obj["term"]
    cond_objs = []
    if query_obj["term_category"] == "any":
        return {'$text': { '$search': query_term}}
    elif query_obj["term_category"] == "glycan":
        cond_objs.append({"glycosylation.glytoucan_ac":{'$regex': query_obj["term"], '$options': 'i'}})
        cond_objs.append({"interactions.interactor_id":{'$regex': query_obj["term"], '$options': 'i'}})
    elif query_obj["term_category"] == "protein":
        cond_objs.append({"uniprot_canonical_ac":{'$regex': query_obj["term"], '$options': 'i'}})
        cond_objs.append({"gene_names.name":{'$regex': query_obj["term"], '$options': 'i'}})
        cond_objs.append({"protein_names.name":{'$regex': query_obj["term"], '$options': 'i'}})
        cond_objs.append({"function.annotation":{'$regex': query_obj["term"], '$options': 'i'}})
        cond_objs.append({"glycosylation.type" : {'$regex':query_obj["term"],'$options': 'i'}})

    
    elif query_obj["term_category"] == "gene":
        cond_objs.append({"gene_names.name":{'$regex': query_obj["term"], '$options': 'i'}})
        cond_objs.append({"gene.locus.evidence.id":{'$regex': query_obj["term"], '$options': 'i'}})
    elif query_obj["term_category"] == "disease":
        prefix_list = [
            "disease.recommended_name", 
            "disease.synonyms",
            "expression_disease.disease.recommended_name",
            "expression_disease.disease.synonyms",
            "snv.disease.recommended_name", 
            "snv.disease.synonyms",
        ]
        for prefix in prefix_list:
            f_one, f_two = prefix + ".name", prefix + ".id"
            cond_objs.append({f_one:{'$regex': query_obj["term"], '$options': 'i'}})
            cond_objs.append({f_two:{'$regex': query_obj["term"], '$options': 'i'}})
    elif query_obj["term_category"] == "pathway":
        cond_objs.append({"pathway.id":{'$regex': query_obj["term"], '$options': 'i'}})
        cond_objs.append({"pathway.name":{'$regex': query_obj["term"], '$options': 'i'}})
    elif query_obj["term_category"] == "organism":
        cond_objs.append({"species.name":{'$regex': query_obj["term"], '$options': 'i'}})
        cond_objs.append({"species.glygen_name":{'$regex': query_obj["term"], '$options': 'i'}})


    mongo_query = {} if cond_objs == [] else { "$or": cond_objs }

    return mongo_query



def get_mongo_query(query_obj, glygen_name_dict):
                        


    cond_objs = []
    #uniprot_canonical_ac
    if "uniprot_canonical_ac" in query_obj:
        qid_list = query_obj["uniprot_canonical_ac"].replace(" ", "").split(",")
        if len(qid_list) == 1:
            uniprot_ac = qid_list[0].split("-")[0]
            cond_objs.append({"uniprot_ac":{'$eq': uniprot_ac}})
        else:
            cond_objs.append(
                {
                    "$or":[
                        {"uniprot_canonical_ac":{'$in': qid_list}},
                        {"uniprot_ac":{'$in': qid_list}},
                        {"uniprot_id":{'$in': qid_list}},
                        {"isoforms.isoform_ac":{'$in': qid_list}} 
                    ]
                }
        )

    #protein_name
    if "protein_name" in query_obj:
        protein_name = query_obj["protein_name"]
        protein_name = protein_name.replace("(", "\(").replace(")", "\)")
        protein_name = protein_name.replace("[", "\[").replace("]", "\]")
        cond_objs.append({"protein_names.name":{'$regex': protein_name, '$options': 'i'}})

    #binding_glycan_id
    if "binding_glycan_id" in query_obj:
        q = {"interactions.interactor_id":{'$eq': query_obj["binding_glycan_id"]}}
        cond_objs.append(q)

    #go_id
    if "go_id" in query_obj:
        q = {"go_annotation.categories.go_terms.id":{'$eq': query_obj["go_id"]}}
        cond_objs.append(q)
    
    #go_term
    if "go_term" in query_obj:
        q = {"go_annotation.categories.go_terms.name":{'$regex': query_obj["go_term"], '$options': 'i'}}
        cond_objs.append(q)

    #refseq_ac
    if "refseq_ac" in query_obj:
        cond_objs.append({"refseq.ac":{'$eq': query_obj["refseq_ac"]}})
    
    #poi_type
    if "poi_type" in query_obj:
        cond_objs.append({"class_list":query_obj["poi_type"]})
    
    #mass
    if "mass" in query_obj:
        if "min" in query_obj["mass"]:
            cond_objs.append({"mass.chemical_mass":{'$gte': query_obj["mass"]["min"]}})
        if "max" in query_obj["mass"]:
            cond_objs.append({"mass.chemical_mass":{'$lte': query_obj["mass"]["max"]}})

    if "mass.min" in query_obj:
        cond_objs.append({"mass.chemical_mass":{'$gte': query_obj["mass.min"]}})
      
    if "mass.max" in query_obj:
        cond_objs.append({"mass.chemical_mass":{'$lte': query_obj["mass.max"]}})

 
 
    #organism
    if "organism" in query_obj:
        if "id" in query_obj["organism"]:
            if type(query_obj["organism"]["id"]) is int:
                cond_objs.append({"species.taxid": {'$eq': query_obj["organism"]["id"]}})
        elif "name" in query_obj["organism"]:
            if query_obj["organism"]["name"] in glygen_name_dict:
                 cond_objs.append({"species.glygen_name": {'$eq': query_obj["organism"]["name"]}})
            else:
                cond_objs.append({"species.glygen_name": {'$regex': query_obj["organism"]["name"], '$options': 'i'}})
    if "organism.id" in query_obj:
        if type(query_obj["organism.id"]) is int:
            cond_objs.append({"species.taxid": {'$eq': query_obj["organism.id"]}})

    #biomarker
    if "biomarker" in query_obj:
        if "id" in query_obj["biomarker"]:
            if len(query_obj["biomarker"]["id"]) > 0:
                o = {"biomarkers.biomarker_id": {'$regex': query_obj["biomarker"]["id"], '$options': 'i'}}
                cond_objs.append(o)
        if "name" in query_obj["biomarker"]:
            if len(query_obj["biomarker"]["name"]) > 0:
                o = {"biomarkers.assessed_biomarker_entity":{'$regex':query_obj["biomarker"]["name"],'$options':'i'}}
                cond_objs.append(o)
        if "type" in query_obj["biomarker"]:
            if len(query_obj["biomarker"]["type"]) > 0:
                o = {"biomarkers.best_biomarker_role": {'$eq': query_obj["biomarker"]["type"]}}
                cond_objs.append(o)
        if "disease_id" in query_obj["biomarker"]:
            if len(query_obj["biomarker"]["disease_id"]) > 0:
                disease_id = query_obj["biomarker"]["disease_id"]
                or_list = [
                    {"biomarkers.condition.id_list":{'$regex':disease_id,'$options':'i'}}
                ]
                cond_objs.append({'$or':or_list})
        if "disease_name" in query_obj["biomarker"]:
            if len(query_obj["biomarker"]["disease_name"]) > 0:
                disease_name = query_obj["biomarker"]["disease_name"]
                or_list = [
                    {"biomarkers.condition.name_list":{'$regex':disease_name,'$options':'i'}}
                ]
                cond_objs.append({'$or':or_list})



    #gene_name
    if "gene_name" in query_obj:
        cond_objs.append({"gene_names.name" : {'$regex': query_obj["gene_name"], '$options': 'i'}})
    if "recommended_gene_name" in query_obj:
        q_val = '^%s$' % (query_obj["recommended_gene_name"])
        cond_objs.append({"gene_names.name" : {'$regex': q_val, '$options': 'i'}})
        cond_objs.append({"gene_names.type" : {'$eq': "recommended"}})

    #pathway_id
    if "pathway_id" in query_obj:
        cond_objs.append({"pathway.id" : {'$eq':query_obj["pathway_id"]}})
    

    #pmid
    if "pmid" in query_obj:
        cond_objs.append({"publication.reference.id" : {'$eq': query_obj["pmid"]}})

    #glycosylation_type and glycosylation_subtype
    if "glycosylation_type" in query_obj:
        if "glycosylation_subtype" in query_obj:
            cond_objs.append({
                "glycosylation": {            
                    "$elemMatch": {             
                        "type": {'$eq': query_obj["glycosylation_type"]},
                        "subtype": {'$eq': query_obj["glycosylation_subtype"]}
                    }
                }
            })
        else:
            cond_objs.append({"glycosylation.type" : {'$regex': query_obj["glycosylation_type"], '$options': 'i'}})
    elif "glycosylation_subtype" in query_obj:
        cond_objs.append({"glycosylation.subtype" : {'$regex': query_obj["glycosylation_subtype"], '$options': 'i'}})

    #attached_glycan_id
    if "attached_glycan_id" in query_obj:
        q_str = query_obj["attached_glycan_id"]
        g_list = q_str.replace(" ", ",").split(",")
        q_one = {
                "$or":[
                    {"glycosylation.glytoucan_ac":{"$in": g_list}},
                    {"glycosylation.glytoucan_ac":{'$eq': q_str}}
                ]
        }
        cond_objs.append(q_one)
    
    #disease name
    if "disease_name" in query_obj:
        or_list = [
            {"disease.recommended_name.name":{'$regex':query_obj["disease_name"],'$options':'i'}},
            {"disease.synonyms.name":{'$regex':query_obj["disease_name"],'$options':'i'}},
            {"biomarkers.condition.name_list":{'$regex':query_obj["disease_name"],'$options':'i'}}
        ]
        cond_objs.append({'$or':or_list})

    #disease ID
    if "disease_id" in query_obj:
        or_list = [
            {"disease.recommended_name.id":{'$eq':query_obj["disease_id"]}},
            {"disease.synonyms.id":{'$eq':query_obj["disease_id"]}},
            {"biomarkers.condition.id_list":{'$eq':query_obj["disease_id"]}}
        ]
        cond_objs.append({'$or':or_list})

    #glycosylation_evidence
    if "glycosylation_evidence" in query_obj:
        ev_type_list = ["sites_reported_with_glycans", "sites_reported_without_glycans", 
            "sites_detected_by_literature_mining", "predicted_sites"]
        ev_type = "sites_reported_with_glycans"
        if query_obj["glycosylation_evidence"] in ev_type_list:
            ev_type = query_obj["glycosylation_evidence"]
        if ev_type == "sites_reported_with_glycans":
            oo = {"glycosylation.site_category_dict.reported_with_glycan":{"$eq":True}}
            cond_objs.append(oo)
        elif ev_type == "sites_reported_without_glycans":
            oo = {"glycosylation.site_category_dict.reported":{"$eq":True}}
            cond_objs.append(oo)
        elif ev_type == "sites_detected_by_literature_mining":
            oo = {"glycosylation.site_category_dict.automatic_literature_mining":{"$eq":True}}
            cond_objs.append(oo)
        elif ev_type  == "predicted_sites":
            or_list = [
                {"glycosylation.site_category_dict.predicted":{"$eq":True}},
                {"glycosylation.site_category_dict.predicted_with_glycan":{"$eq":True}}
            ]
            cond_objs.append({"$or":or_list})
            


    #sequence
    if "sequence" in query_obj:
        if "aa_sequence" in query_obj["sequence"]:
            val = query_obj["sequence"]["aa_sequence"]
            val = val.replace("X", "[A-Z]{1}")
            cond_objs.append({"sequence.sequence": {'$regex':val,'$options': 'i'}})

    if "sequence.aa_sequence" in query_obj:
        val = query_obj["sequence.aa_sequence"] 
        val = val.replace("X", "[A-Z]{1}")
        cond_objs.append({"sequence.sequence": {'$regex':val,'$options': 'i'}})

 
    operation = query_obj["operation"].lower() if "operation" in query_obj else "and"
    mongo_query = {}
    mongo_query = cond_objs[0] if len(cond_objs) == 1 else mongo_query
    mongo_query = { "$"+operation+"": cond_objs } if len(cond_objs) > 1 else mongo_query
       
    return mongo_query















def get_protein_list_object(obj):


    uniprot_canonical_ac = obj["uniprot_canonical_ac"]
    mass = -1
    if "mass" in obj:
        if "chemical_mass" in obj["mass"]:
            mass = obj["mass"]["chemical_mass"]
       
    protein_name, protein_names_uniprotkb, protein_names_refseq = "", "", ""
    if "protein_names" in obj:
        protein_name = extract_name(obj["protein_names"], "recommended", "UniProtKB")
        protein_names_uniprotkb = extract_name(obj["protein_names"], "all", "UniProtKB")
        protein_names_refseq = extract_name(obj["protein_names"], "all", "RefSeq")


    refseq_ac, refseq_name = "", ""
    if "refseq" in obj:
        refseq_ac = obj["refseq"]["ac"] if "ac" in obj["refseq"] else ""
        refseq_name = obj["refseq"]["name"] if "name" in obj["refseq"] else ""

    gene_name, gene_names_uniprotkb, gene_names_refseq = "", "", ""
    if "gene_names" in obj:
        gene_name = extract_name(obj["gene_names"], "recommended", "UniProtKB")
        gene_names_uniprotkb = extract_name(obj["gene_names"], "all", "UniProtKB")
        gene_names_refseq = extract_name(obj["gene_names"], "all", "RefSeq")



    organism_name, tax_id = "", 0
    if "species" in obj:
        if len(obj["species"]) > 0:
            organism_name = obj["species"][0]["name"] if "name" in obj["species"][0] else ""
            tax_id = obj["species"][0]["taxid"] if "taxid" in obj["species"][0] else 0
   
    disease_list = []
    if "disease" in obj:
        for o in obj["disease"]:
            disease_id = o["recommended_name"]["id"]
            disease_name = o["recommended_name"]["name"]
            resource = o["recommended_name"]["resource"]
            disease_list.append("%s (%s:%s)" % (disease_name, resource, disease_id))
    disease = "; ".join(disease_list)


    pathway_list = []
    if "pathway" in obj:
        for o in obj["pathway"]:
            pathway_id = o["id"]
            pathway_name = o["name"]
            pathway_list.append("%s (%s)" % (pathway_name, pathway_id))
    pathway = "; ".join(pathway_list)


    function_list = []
    if "function" in obj:
        for o in obj["function"]:
            ann = o["annotation"]
            badge_list= []
            for e in o["evidence"]:
                badge_list.append(e["database"])
            function_list.append("%s, [%s]" % (ann,", ".join(badge_list)))
    function = "; ".join(function_list)
    
    publication_count = 0
    if "publication" in obj:
        publication_count = len(obj["publication"])
  
    predicted_glycosites =  0
    reported_n_glycosites, reported_o_glycosites = 0,0
    reported_n_glycosites_with_glycan, reported_o_glycosites_with_glycan = 0,0

    if "glycosylation" in obj:
        for o in obj["glycosylation"]:
            #if o["position"] == "":
            #    continue
            site_type = o["type"].lower()

            if "predicted" in o["site_category_dict"]:
                predicted_glycosites += 1
            if site_type == "n-linked" and "reported" in o["site_category_dict"]:
                reported_n_glycosites += 1
            if site_type == "o-linked" and "reported" in o["site_category_dict"]: 
                reported_o_glycosites += 1
            if site_type == "n-linked" and "reported_with_glycan" in o["site_category_dict"]:
                reported_n_glycosites_with_glycan += 1
            if site_type == "o-linked" and "reported_with_glycan" in o["site_category_dict"]: 
                reported_o_glycosites_with_glycan += 1

    o = {
        "uniprot_canonical_ac":uniprot_canonical_ac
        ,"mass": mass
        ,"protein_name":protein_name
        ,"gene_name":gene_name
        ,"organism":organism_name
        ,"refseq_name": refseq_name
        ,"refseq_ac": refseq_ac
        ,"gene_names_uniprotkb":gene_names_uniprotkb
        ,"gene_names_refseq":gene_names_refseq
        ,"protein_names_uniprotkb":protein_names_uniprotkb
        ,"protein_names_refseq":protein_names_refseq
        ,"tax_id":tax_id
        ,"disease":disease
        ,"pathway":pathway
        ,"publication_count":publication_count
        ,"function":function
        ,"predicted_glycosites":predicted_glycosites
        ,"reported_n_glycosites":reported_n_glycosites
        ,"reported_o_glycosites":reported_o_glycosites
        ,"reported_n_glycosites_with_glycan":reported_n_glycosites_with_glycan
        ,"reported_o_glycosites_with_glycan":reported_o_glycosites_with_glycan
    }


    return o


def get_unmapped_obj_list(query_value, seen_id):

    unmapped_obj_list, redundancy_dict = [], {}
    qid_list = query_value.replace(" ", "").split(",")
    qid_list = [qid.split("-")[0] for qid in qid_list]
    for qid in qid_list:
        if qid not in seen_id:
            unmapped_obj_list.append({"input_id":qid, "reason":"ID not found"})
        if qid_list.count(qid) > 1:
            redundancy_dict[qid] = qid_list.count(qid)
    for qid in redundancy_dict:
        for i in range(redundancy_dict[qid] - 1):
            unmapped_obj_list.append({"input_id":qid, "reason":"Duplicate ID"})

    return unmapped_obj_list



def get_expressed_proteins(dbh, query_obj):
   
    seen = {}
    qry_obj = {"expression_tissue.tissue.id" : {'$eq':query_obj["tissue_id"]}}
    prj_obj = {"uniprot_canonical_ac":1, "expression_tissue":1}
    for doc in dbh["c_protein"].find(qry_obj, prj_obj):
        canon = doc["uniprot_canonical_ac"]
        for obj in doc["expression_tissue"]:
            if obj["tissue"]["id"] == query_obj["tissue_id"] and obj["present"] in ["HIGH", "MEDIUM"]:
                seen[canon] = True

    return list(seen.keys())



def get_hit_dict(dbh, sf_dict, field2sec, api_name, glygen_name_dict, config_obj):
    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts_list = []
   
    record_type = api_name.split("_")[0]
    hit_dict, hit_stat, seen_id = {}, {}, {}
    coll = "c_" + record_type

    mongo_query_single = {}
    for f in sf_dict:
        ts_list.append(f)
        ts_list.append("x-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))
        query_obj_single = {f:sf_dict[f], "operation":"AND", "query_type":"search_protein"}
        list_id_single = get_hash_id(api_name, record_type, query_obj_single)
        cached_obj_single = dbh["c_initcache"].find_one({"list_id":list_id_single})
        if cached_obj_single != None:
            hit_dict[f] = []
            for doc in dbh["c_initcache"].find({"list_id":list_id_single}):
                hit_dict[f] += doc["results"] if "results" in doc else []
            hit_stat[f] = {"n":len(hit_dict[f]), "flag":"1"}
        elif f in field2sec:
            hit_dict[f] = []
            sec = field2sec[f]
            f_parts = f.split(".")
            val = sf_dict[f]
            if type(val) is dict:
                for ff in f_parts[1:]:
                    val = val[ff]
            query_obj_new = {"term":val,"term_category":sec}
            api_name_simple = "%s_search_simple" % (record_type)
            exact_match_flag = True
            #xxxx = search_one(api_name_simple, query_obj_new, config_obj, True, exact_match_flag)
            #return xxxx
            res = use_indexed_search(api_name_simple, query_obj_new,config_obj,exact_match_flag)
            if "error_list" not in res:
                for doc in dbh["c_usercache"].find({"list_id":res["list_id"]}):
                    hit_dict[f] += doc["results"] if "results" in doc else []
            hit_stat[f] = {"n":len(hit_dict[f]), "flag":"2", "query":query_obj_new}
        elif f == "glycosylated_aa":
            aa_list = sf_dict[f]["aa_list"]
            op = sf_dict[f]["operation"]
            hit_dict[f] = run_special_query(dbh, coll,api_name, record_type, aa_list, op)
            hit_stat[f] = {"n":len(hit_dict[f]), "flag":"3"}
        elif f == "uniprot_canonical_ac":
            hit_dict[f] = []
            mongo_query_single = get_mongo_query(query_obj_single, glygen_name_dict)
            prj_obj = {"uniprot_canonical_ac":1, "uniprot_ac":1, "uniprot_id":1, "isoforms.isoform_ac":1}
            for obj in dbh[coll].find(mongo_query_single,prj_obj):
                canon = obj["uniprot_canonical_ac"]
                hit_dict[f].append(canon)
                uniprot_ac, uniprot_id = obj["uniprot_ac"], obj["uniprot_id"]
                seen_id[canon] = True
                seen_id[uniprot_ac] = True
                seen_id[uniprot_id] = True
                for o in obj["isoforms"]:
                    seen_id[o["isoform_ac"]] = True
            hit_stat[f] = {"n":len(hit_dict[f]), "flag":"4", "mquery":mongo_query_single, "qobj":query_obj_single}
        else:
            mongo_query_single = get_mongo_query(query_obj_single, glygen_name_dict)
            #return {"in":query_obj_single,  "out":mongo_query_single}
            if mongo_query_single != {}:
                hit_dict[f] = []
                prj_obj = {"uniprot_canonical_ac":1}
                for obj in dbh[coll].find(mongo_query_single,prj_obj):
                    canon = obj["uniprot_canonical_ac"]
                    hit_dict[f].append(canon)
                hit_stat[f] = {"f":f, "n":len(hit_dict[f]), "flag":"5", "mquery":mongo_query_single, "qobj":query_obj_single}
        ts_list.append("1y-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))

    return hit_dict, hit_stat, seen_id, ts_list, mongo_query_single






def run_special_query(dbh, collection,api_name, record_type, aa_list, op):

    aa_map = {
        "A":"Ala","R":"Arg","N":"Asn","D":"Asp","C":"Cys","E":"Glu","Q":"Gln",
        "G":"Gly","H":"His","I":"Ile","L":"Leu","K":"Lys","M":"Met","F":"Phe",
        "P":"Pro","S":"Ser","T":"Thr","W":"Trp","Y":"Tyr","V":"Val"
    }

    ts_format = "%Y-%m-%d %H:%M:%S %Z%z"
    ts_list = []
    ts_list.append("aa-"+datetime.datetime.now(pytz.timezone('US/Eastern')).strftime(ts_format))


    hit_dict_local = {}
    for aa in aa_list:
        qry_single = {"glycosylated_aa":{"aa_list":[aa], "operation": op},
            "operation":"AND", "query_type":"search_protein"
        }
        list_id_single = get_hash_id(api_name, record_type, qry_single)
        cached_obj_single = dbh["c_initcache"].find_one({"list_id":list_id_single})
        if cached_obj_single != None:
            hit_dict_local[aa] = []
            for doc in dbh["c_initcache"].find({"list_id":list_id_single}):
                hit_dict_local[aa] += doc["results"]
        else:
            aa_three = aa_map[aa] if aa in aa_map else aa
            qry_obj = {"glycosylation.residue":{"$eq":aa_three}}
            prj_obj = {"uniprot_canonical_ac":1}
            tmp_dict = {}
            for obj in dbh[collection].find(qry_obj,prj_obj):
                canon = obj["uniprot_canonical_ac"]
                tmp_dict[canon] = True
            hit_dict_local[aa] = list(tmp_dict.keys())
            
    record_list = []
    if op == "and":
        record_list = hit_dict_local[aa_list[0]]
        if len(aa_list) > 1:
            for aa in aa_list[1:]:
                record_list = list(set(record_list).intersection(set(hit_dict_local[aa])))
    else:
        for aa in hit_dict_local:
            record_list += hit_dict_local[aa]
        record_list = list(set(record_list))

    return record_list
